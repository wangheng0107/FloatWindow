# ViewDragDemo
## 支持滑动dragview，同时动态调整上下两部分的高度，也支持webview的加载和动态调整webview的高度，webview不受动态高度的影响而绘制受影响
参考的博客：https://blog.csdn.net/lmj623565791/article/details/46858663
# 效果图：
![](SceenShoot/Record_2023-03-24-12-08-37.gif)